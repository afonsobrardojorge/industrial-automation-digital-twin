# Methodology and validation approach

## Control design

The control logic is modelled as a finite-state machine:

1. **Stopped**: system awaits operator start.
2. **Automatic**: conveyor runs and incoming parts are classified.
3. **Manual**: operator can command conveyor and reject actuator directly.
4. **Emergency stop**: outputs are forced to a simulated safe state until reset.

## Validation strategy

The Structured Text source is complemented by a deterministic Python reference model. The model exposes the same primary state transitions and production counters and is validated through automated unit tests.

The tests cover:

- automatic start and conveyor actuation;
- accepted/rejected part accounting;
- emergency-stop safe-state behaviour;
- manual-mode command handling;
- maintenance-threshold alerting.

## Known limitations

- The Python model is a behavioural reference, not a byte-for-byte PLC runtime emulator.
- Timer resolution and hardware scan-cycle effects are not represented in the simulator.
- No physical sensor noise, motor dynamics or network latency are modelled.
- The project does not implement a certified functional-safety architecture.
