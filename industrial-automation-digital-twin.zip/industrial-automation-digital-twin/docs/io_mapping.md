# I/O mapping

The following mapping is used by `plc/conveyor_sorter.st`. Addresses are illustrative and must be reviewed for the target runtime and hardware.

## Inputs

| Address | Signal | Description |
|---|---|---|
| `%IX0.0` | `StartButton` | Starts the cell in automatic or manual mode |
| `%IX0.1` | `StopButton` | Requests normal stop |
| `%IX0.2` | `EmergencyStop` | Emergency-stop simulation input |
| `%IX0.3` | `ManualModeSelect` | Selects manual mode |
| `%IX0.4` | `PartSensor` | Detects a product entering the quality station |
| `%IX0.5` | `QualityFailSensor` | Marks the detected product as defective |
| `%IX0.6` | `RejectPositionSensor` | Confirms that the reject area is clear |
| `%IX0.7` | `ResetFaultButton` | Allows reset after emergency-stop release |
| `%IX1.0` | `ManualConveyorCmd` | Manual conveyor command |
| `%IX1.1` | `ManualRejectCmd` | Manual reject-cylinder command |

## Outputs

| Address | Signal | Description |
|---|---|---|
| `%QX0.0` | `ConveyorMotor` | Conveyor motor command |
| `%QX0.1` | `RejectCylinder` | Reject-cylinder command |
| `%QX0.2` | `RunningLamp` | Automatic-operation indicator |
| `%QX0.3` | `FaultLamp` | Emergency-stop/fault indicator |
| `%QX0.4` | `ReadyLamp` | Stopped/manual-ready indicator |
| `%QX0.5` | `MaintenanceLamp` | Preventive-maintenance indicator |

> **Important:** An emergency-stop circuit on real equipment must be implemented with approved hardware safety components. Mapping an E-stop to normal PLC software input is sufficient only for this simulated educational example.
