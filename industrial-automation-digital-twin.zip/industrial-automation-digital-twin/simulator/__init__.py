"""Reproducible simulation scenario."""
